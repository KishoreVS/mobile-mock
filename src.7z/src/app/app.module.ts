import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DisplatmobileComponent } from './displatmobile/displatmobile.component';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { MobileService } from './mobile.service';
import {FormsModule} from '@angular/forms';
import { OrderbyPipe } from './orderby.pipe';
import { SearchComponent } from './search/search.component';
@NgModule({
  declarations: [
    AppComponent,
    DisplatmobileComponent,
    OrderbyPipe,
    SearchComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [HttpClient,MobileService],
  bootstrap: [AppComponent]
})
export class AppModule { }

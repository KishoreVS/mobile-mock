import { Component, OnInit } from '@angular/core';
import { MobileService,Mobile } from '../mobile.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
service:MobileService
  constructor(service:MobileService) {
    this.service=service;
   }
   mobile:Mobile[]=[];


  ngOnInit() {
    this.service.fetchMobile();
  }
  search(data:any)
  {
    let mobId:number=data.mobId;
    this.mobile=this.service.search(mobId);
  }

}

import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DisplatmobileComponent } from './displatmobile/displatmobile.component';
import { SearchComponent } from './search/search.component';


const routes: Routes = [
  {
    path:'app-search',
    component: SearchComponent
  },
  {
    path:'app-displatmobile',
    component: DisplatmobileComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

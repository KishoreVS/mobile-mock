import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DisplatmobileComponent } from './displatmobile.component';

describe('DisplatmobileComponent', () => {
  let component: DisplatmobileComponent;
  let fixture: ComponentFixture<DisplatmobileComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DisplatmobileComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DisplatmobileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit } from '@angular/core';
import { MobileService,Mobile } from '../mobile.service';

@Component({
  selector: 'app-displatmobile',
  templateUrl: './displatmobile.component.html',
  styleUrls: ['./displatmobile.component.css']
})
export class DisplatmobileComponent implements OnInit {
  service:MobileService;
  constructor(service:MobileService) {
    this.service=service;
   }
   mobile:Mobile[]=[];
   delete(mobId:number)  //to delete the mobile details(method calling)
   {
     this.service.delete(mobId);
     this.mobile=this.service.getMobile();
   }
   column:string="mobId";
   order:boolean=true;
   sort(column:string)  //to sort the rows in ascending order
   {
     if(this.column=column)
     {
       this.order=!this.order;
     }
     else{
       this.order=true;
       this.column=column;
     }
   }
  ngOnInit() {
    this.service.fetchMobile();
    this.mobile=this.service.getMobile();
  }

}

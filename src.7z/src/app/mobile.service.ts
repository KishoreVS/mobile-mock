import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class MobileService {
http:HttpClient;
mobile:Mobile[]=[];  //object creation
  constructor(http:HttpClient) { 
    this.http=http;
    this.fetchMobile();
  }
  fetched:boolean=false;
  fetchMobile() //to fetch the mobile details from the json file
  {
    this.http.get('./assets/mobile.json')
    .subscribe
    (
      data=>
      {
        if(!this.fetched)
        {
          this.convert(data);
          this.fetched=true;
        }
      }
    );
  }
  getMobile():Mobile[] //to get the details 
  {
    return this.mobile;
  }
  convert(data:any) //to push the data into the table
  {
    for(let m of data)
    {
      let o=new Mobile(m.mobId,m.mobName,m.mobPrice);
      this.mobile.push(o);
    }
  }
  delete(mobId:number) //to delete the mobile details(method definition)
  {
    let foundIndex:number=-1;
    for(let i=0;i<this.mobile.length;i++)
    {
      let m=this.mobile[i];
      if(mobId==m.mobId)
      {
        foundIndex=1;
        break;
      }
    }
    this.mobile.splice(foundIndex,1);
  }
  search(mobId:number):Mobile[]
  {
    let resultMob:Mobile[]=[];
    console.log(mobId)
    let o:Mobile;
    var flag=0;
    for(let i=0;i<this.mobile.length;i++)
    {
    
      o=this.mobile[i];
      if(mobId==o.mobId)
      {
        resultMob.push(o);
        flag=1;
      }
    }
      if(flag==0)
      {
        alert("The Mobile ID "+mobId+" does not exist");
      }
      return resultMob;
    }
  
}
export class Mobile  //to store the details 
{
  mobId:number;
  mobName:string;
  mobPrice:number;
  constructor(mobId:number,mobName:string,mobPrice:number)
  {
    this.mobId=mobId;
    this.mobName=mobName;
    this.mobPrice=mobPrice;
  }
}

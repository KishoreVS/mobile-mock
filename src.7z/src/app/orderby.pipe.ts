import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'orderby'
})
export class OrderbyPipe implements PipeTransform {

  transform(array: any, line:string,order:boolean) {
    if(line==undefined)
    {
      return array;
    }
    let result:any[];
    return result=this.ascending(array,line);
  }
  ascending(array:any[],line:string)  //to sort the rows in ascending order
  {
    array.sort((a:any,b:any)=>{
      if(a[line]>b[line])
      {
        return 1;
      }
      return -1;
    }
    );
    return array;
  }



}
